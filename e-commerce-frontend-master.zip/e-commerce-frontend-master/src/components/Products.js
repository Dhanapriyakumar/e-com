import React from "react";
import MainContent from "./MainContent.js";
import "./styles/Products.css";

const Products = () => {
  return (
    <div className="product_container">
      <MainContent />
    </div>
  );
};

export default Products;
